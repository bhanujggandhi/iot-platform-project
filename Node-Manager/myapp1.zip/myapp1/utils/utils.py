def hello(name: str):
    return name
